//
//  ViewController.swift
//  AppEventCount
//
//  Created by Samantha Ramirez on 23/04/24.
//

import UIKit

class ViewController: UIViewController {

    //AppDelegate
    @IBOutlet weak var didFinishLaunchingLabel: UILabel!
    
    @IBOutlet weak var configurationForConnectingLabel: UILabel!
    
    //SceneDelegate
    @IBOutlet weak var willConnectLabel: UILabel!
    
    @IBOutlet weak var DidBecomeActiveLabel: UILabel!
    
    @IBOutlet weak var WillResignActiveLabel: UILabel!
    
    @IBOutlet weak var WillEnterForegroundLabel: UILabel!
    
    @IBOutlet weak var DidEnterBackgroundLabel: UILabel!
    
    var willConectCount = 0
    var didBecomeActiveCount = 0
    var willResignActiveCount = 0
    var willEnterForegroundCount = 0
    var didEnterBackgroundCount = 0
    
    var appDelegate = (UIApplication.shared.delegate as! AppDelegate)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateView()
    }
    
    func updateView() {
        //Actualizar etiquetas de AppDelegate
        didFinishLaunchingLabel.text = "The App has launched \(appDelegate.launchCount) time(s)"
        configurationForConnectingLabel.text = "The App has configured for connecting \(appDelegate.configurationForConnectingCount) time(s)"
        
        //Actualizar etiquetas de SeceneDelegate
        willConnectLabel.text = "The Scene will connect \(willConectCount) time(s)"
        DidBecomeActiveLabel.text = "The Scene did become active \(didBecomeActiveCount) time(s)"
        WillResignActiveLabel.text = "The Scene will resign active \(willResignActiveCount) time(s)"
        WillEnterForegroundLabel.text = "The Scene will enter foreground \(willEnterForegroundCount) time(s)"
        DidEnterBackgroundLabel.text = "The Scene did enter background \(didEnterBackgroundCount) time(s)"
    }
    
}
